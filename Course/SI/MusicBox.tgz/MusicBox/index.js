document.currentScript.value=[
	"Shiding/HighSchool.js",
	"Chihlee/BanqiaoBreeze.js",
	"Chihlee/HappyFinance.js"
];
