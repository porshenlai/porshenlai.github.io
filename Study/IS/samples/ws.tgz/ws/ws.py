import asyncio
import json
import os
from sys import path as modpath
from aiohttp import web 
import aiofiles 

# 1. 匯入新的 DatabaseManager

modpath.append(os.path.dirname(os.path.realpath(__file__)));

from user_db import DatabaseManager

# -----------------
# 1. 配置與輔助函式
# -----------------
DATA_DIR = "data"
DB_FILE = os.path.join(DATA_DIR, "users.db")
# 新增 DOCS_DIR
DOCS_DIR = "docs" 

# 建立 DatabaseManager 實例
db_manager = DatabaseManager(db_path=DB_FILE)

# (保留您原本的 save_to_json 函式)
async def save_to_json(filename: str, data: dict):
    file_path = os.path.join(DATA_DIR, filename)
    os.makedirs(DATA_DIR, exist_ok=True)
    async with aiofiles.open(file_path, mode="w", encoding="utf-8") as f:
        content = json.dumps(data, ensure_ascii=False, indent=4)
        await f.write(content)
    print(f"成功將資料寫入: {file_path}")
    return file_path

# -----------------
# 2. 新的使用者管理 Handlers
# -----------------
async def handle_register(request):
    """處理 POST /api/register - 註冊新使用者"""
    try:
        data = await request.json()
        username = data.get("username")
        pwd_hash = data.get("pwd_hash") # 假設前端已傳來雜湊後的密碼

        if not username or not pwd_hash:
            return web.json_response({"status": "error", "message": "缺少 username 或 pwd_hash。"}, status=400)

        result = await db_manager.register_user(
            username=username,
            pwd_hash=pwd_hash,
            name=data.get("name"),
            email=data.get("email"),
            phone=data.get("phone")
        )

        if result["success"]:
            return web.json_response({"status": "success", "message": result["message"]}, status=201)
        else:
            # 409 Conflict 通常用於資源已存在的情況
            return web.json_response({"status": "error", "message": result["message"]}, status=409)

    except json.JSONDecodeError:
        return web.json_response({"status": "error", "message": "無效的 JSON 格式。"}, status=400)
    except Exception as e:
        return web.json_response({"status": "error", "message": f"伺服器錯誤: {e}"}, status=500)

async def handle_login(request):
    """處理 POST /api/login - 驗證使用者"""
    try:
        data = await request.json()
        identifier = data.get("identifier") # 可以是 username, email 或 phone
        pwd_hash = data.get("pwd_hash")

        if not identifier or not pwd_hash:
            return web.json_response({"status": "error", "message": "缺少 identifier 或 pwd_hash。"}, status=400)
            
        user_data = await db_manager.verify_user(identifier, pwd_hash)

        if user_data:
            return web.json_response({
                "status": "success",
                "message": "登入成功。",
                "user": user_data
            })
        else:
            return web.json_response({"status": "error", "message": "憑證無效。"}, status=401) # 401 Unauthorized

    except json.JSONDecodeError:
        return web.json_response({"status": "error", "message": "無效的 JSON 格式。"}, status=400)
    except Exception as e:
        return web.json_response({"status": "error", "message": f"伺服器錯誤: {e}"}, status=500)

async def handle_delete_user(request):
    """處理 DELETE /api/user/{username} - 刪除使用者"""
    username = request.match_info.get('username')
    if not username:
        return web.json_response({"status": "error", "message": "缺少使用者名稱。"}, status=400)

    success = await db_manager.delete_user(username)

    if success:
        return web.json_response({"status": "success", "message": f"使用者 '{username}' 已被刪除。"})
    else:
        return web.json_response({"status": "error", "message": f"找不到使用者 '{username}'。"}, status=404) # 404 Not Found


# -----------------
# 3. 啟動伺服器
# -----------------
async def main():
    # 在啟動 App 前，先執行資料庫設定
    await db_manager.setup()
    
    app = web.Application()
    
    # 註冊所有路由
    app.add_routes([
        # 保留您原本的路由
        # web.post('/api/save/{filename}', handle_post_with_filename),
        
        # 新增使用者管理的路由
        web.post('/api/register', handle_register),
        web.post('/api/login', handle_login),
        web.delete('/api/user/{username}', handle_delete_user),
        
        # 新增靜態檔案路由：
        # /docs/ 路徑下的所有 GET 請求會對應到本地的 'docs' 目錄。
        # 範例：若有一個檔案 docs/manual.html，則可以透過 http://0.0.0.0:8080/docs/manual.html 存取。
        web.static('/', DOCS_DIR), #
    ])

    print("啟動 aiohttp 伺服器於 http://0.0.0.0:8080")
    
    # 使用 aiohttp 的 Runner 來啟動應用
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, '0.0.0.0', 8080)
    await site.start()
    
    print("伺服器運行中，按下 Ctrl+C 停止。")
    await asyncio.Event().wait()


if __name__ == '__main__':
    # 注意：由於 aiohttp.web.run_app() 會自行管理事件迴圈，
    # 為了能優雅地整合非同步啟動任務，改用 AppRunner 的方式。
    # 建議先手動建立 docs/ 目錄以避免錯誤。
    os.makedirs(DOCS_DIR, exist_ok=True) 
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("伺服器已停止。")
