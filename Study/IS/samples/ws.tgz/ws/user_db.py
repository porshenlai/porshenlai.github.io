# user_db.py
import aiosqlite
import os
from typing import Optional, Dict, Any

class DatabaseManager:
    """
    一個非同步的使用者資料庫管理類別，使用 aiosqlite。

    功能包括：
    - 初始化資料庫和資料表。
    - 註冊新使用者。
    - 驗證使用者憑證。
    - 刪除使用者。
    """
    def __init__(self, db_path: str):
        """
        初始化 DatabaseManager。

        Args:
            db_path: SQLite 資料庫檔案的路徑。
        """
        self.db_path = db_path
        # 確保資料庫所在的資料夾存在
        os.makedirs(os.path.dirname(db_path), exist_ok=True)

    async def setup(self):
        """
        建立資料庫和 users 資料表 (如果不存在)。
        此方法應在應用程式啟動時呼叫。
        """
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    username TEXT PRIMARY KEY,
                    pwd_hash TEXT NOT NULL,
                    name TEXT,
                    email TEXT UNIQUE,
                    phone TEXT UNIQUE
                )
            """)
            await db.commit()
        print(f"資料庫 '{self.db_path}' 初始化完成。")

    async def register_user(self, username: str, pwd_hash: str, name: Optional[str] = None, 
                            email: Optional[str] = None, phone: Optional[str] = None) -> Dict[str, Any]:
        """
        註冊一個新使用者。

        Args:
            username: 使用者名稱 (主鍵)。
            pwd_hash: 雜湊後的密碼。
            name: 使用者姓名 (可選)。
            email: 電子郵件 (可選，但必須唯一)。
            phone: 電話號碼 (可選，但必須唯一)。

        Returns:
            一個包含成功狀態和訊息的字典。
        """
        try:
            async with aiosqlite.connect(self.db_path) as db:
                await db.execute(
                    "INSERT INTO users (username, pwd_hash, name, email, phone) VALUES (?, ?, ?, ?, ?)",
                    (username, pwd_hash, name, email, phone)
                )
                await db.commit()
            return {"success": True, "message": f"使用者 '{username}' 註冊成功。"}
        except aiosqlite.IntegrityError as e:
            # 處理主鍵或唯一鍵衝突
            error_msg = str(e).lower()
            if "unique constraint failed: users.username" in error_msg:
                message = "此使用者名稱已被註冊。"
            elif "unique constraint failed: users.email" in error_msg:
                message = "此電子郵件已被註冊。"
            elif "unique constraint failed: users.phone" in error_msg:
                message = "此電話號碼已被註冊。"
            else:
                message = "資料庫完整性錯誤。"
            return {"success": False, "message": message}
        except Exception as e:
            return {"success": False, "message": f"發生未知錯誤: {e}"}

    async def verify_user(self, identifier: str, pwd_hash: str) -> Optional[Dict[str, Any]]:
        """
        驗證使用者身分。

        Args:
            identifier: 使用者的唯一識別碼 (可以是 username, email, 或 phone)。
            pwd_hash: 用於比對的雜湊密碼。

        Returns:
            如果驗證成功，返回包含使用者資料的字典；否則返回 None。
        """
        query = """
            SELECT username, name, email, phone FROM users
            WHERE (username = ? OR email = ? OR phone = ?) AND pwd_hash = ?
        """
        async with aiosqlite.connect(self.db_path) as db:
            # 將 row_factory 設為 aiosqlite.Row 可以讓我們用欄位名稱存取資料
            db.row_factory = aiosqlite.Row
            async with db.execute(query, (identifier, identifier, identifier, pwd_hash)) as cursor:
                user_row = await cursor.fetchone()
        
        if user_row:
            return dict(user_row) # 將 aiosqlite.Row 轉換為字典
        return None

    async def delete_user(self, username: str) -> bool:
        """
        根據使用者名稱刪除使用者。

        Args:
            username: 要刪除的使用者名稱。

        Returns:
            如果成功刪除返回 True，否則返回 False。
        """
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute("DELETE FROM users WHERE username = ?", (username,))
            await db.commit()
            # rowcount 會回傳受影響的資料行數
            return cursor.rowcount > 0