import argparse
import asyncio
import os
import json
import time
import uuid

# 異步函式庫
from aiohttp import web
import aiosqlite
from passlib.hash import pbkdf2_sha256

# --- 1. 命令行參數解析 ---

def parse_args():
    """解析命令行參數，獲取服務器端口和根目錄。"""
    parser = argparse.ArgumentParser(description="aiohttp 文件和認證服務器。")
    parser.add_argument("-p", "--port", type=int, default=8080, help="服務器監聽端口 (預設: 8080)")
    parser.add_argument("-r", "--root", type=str, required=True, help="根目錄 {ROOT}，用於儲存資料庫和文件。")
    return parser.parse_args()

# --- 2. 資料庫操作類 (DBManager) ---

class DBManager:
    """管理 SQLite 資料庫連接和初始化。"""
    
    def __init__(self, root_dir):
        # 設置資料庫和儲存文件的路徑
        self.db_dir = os.path.join(root_dir, 'store')
        self.db_path = os.path.join(self.db_dir, 'server_data.db')
        self.root_dir = root_dir # 根目錄
        self.store_dir = self.db_dir # 文件儲存目錄

    async def init_db(self):
        """檢查並創建資料庫目錄和表格。"""
        
        # 創建 store/ 目錄
        if not os.path.exists(self.db_dir):
            os.makedirs(self.db_dir)
            print(f"創建儲存目錄: {self.db_dir}")

        # 連接資料庫 (如果不存在則創建)
        async with aiosqlite.connect(self.db_path) as db:
            # a. User Table: username(PRIMARY), phone, email, password(hashed)
            await db.execute("""
                CREATE TABLE IF NOT EXISTS User (
                    username TEXT PRIMARY KEY,
                    phone TEXT,
                    email TEXT,
                    password TEXT NOT NULL
                )
            """)
            
            # b. Session Table: session_key(PRIMARY), active_time, username
            # session_key 是 UUID，active_time 是時間戳
            await db.execute("""
                CREATE TABLE IF NOT EXISTS Session (
                    session_key TEXT PRIMARY KEY,
                    active_time INTEGER NOT NULL,
                    username TEXT NOT NULL,
                    FOREIGN KEY (username) REFERENCES User(username)
                )
            """)

            # c. Mission Table: target(path), create_time, session_key
            # target 是文件相對路徑
            await db.execute("""
                CREATE TABLE IF NOT EXISTS Mission (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    target TEXT NOT NULL,
                    create_time INTEGER NOT NULL,
                    session_key TEXT NOT NULL,
                    FOREIGN KEY (session_key) REFERENCES Session(session_key)
                )
            """)
            
            await db.commit()
        print(f"資料庫初始化完成: {self.db_path}")

    # --- 資料庫輔助方法 ---

    async def execute(self, query, params=()):
        """執行 SQL 查詢 (如 INSERT, UPDATE, DELETE)。"""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(query, params)
            await db.commit()

    async def fetchone(self, query, params=()):
        """執行 SQL 查詢並返回單行結果 (字典格式)。"""
        async with aiosqlite.connect(self.db_path) as db:
            db.row_factory = aiosqlite.Row # 設置為字典行
            cursor = await db.execute(query, params)
            row = await cursor.fetchone()
            return dict(row) if row else None

    async def fetchall(self, query, params=()):
        """執行 SQL 查詢並返回所有結果 (字典格式列表)。"""
        async with aiosqlite.connect(self.db_path) as db:
            db.row_factory = aiosqlite.Row
            cursor = await db.execute(query, params)
            rows = await cursor.fetchall()
            return [dict(row) for row in rows]
            
    # --- 認證和會話檢查 ---

    async def verify_session(self, session_key):
        """檢查會話鍵是否有效且未過期 (例如 1 小時)。"""
        # 可以設置一個過期時間 (例如 3600 秒 = 1 小時)
        EXPIRY_TIME = 3600 
        current_time = int(time.time())
        
        session = await self.fetchone(
            "SELECT username FROM Session WHERE session_key = ? AND (? - active_time) < ?",
            (session_key, current_time, EXPIRY_TIME)
        )
        
        if session:
            # 如果會話有效，更新 active_time
            await self.execute(
                "UPDATE Session SET active_time = ? WHERE session_key = ?",
                (current_time, session_key)
            )
            return session['username']
        return None # 會話無效或過期

# --- 3. 視圖處理函式 (Handlers) ---

# 設置 JSON 響應輔助函式
def json_response(data, status=200):
    return web.Response(
        text=json.dumps(data), 
        status=status, 
        content_type='application/json'
    )

async def handle_get_static(request):
    """
    功能 2. HTTP GET 請求: 響應 {ROOT}/docs/ 下的文件。
    這個函數只是作為註釋說明。在 aiohttp 中，我們會使用 `router.add_static()` 來處理。
    但為了展示文件訪問權限，我們仍然使用 web.FileResponse 處理。
    """
    # 實際在主程式中已使用 app.router.add_static() 處理，此處僅作為 API 說明。
    # 由於您的要求是響應 {ROOT}/docs，我們會在 main 函數中設置靜態路由。
    # 這裡的 / 和 /index.html 會被靜態路由處理。
    # 如果用戶訪問 /，將會響應 {ROOT}/docs/index.html (如果存在)。
    raise web.HTTPNotFound() # 讓 add_static 處理

# --- POST API 處理函式 ---

async def api_login(request):
    """
    功能 3. POST API - /__api__/login/ : 驗證用戶名和密碼，創建/更新會話鍵。
    """
    db_manager = request.app['db_manager']
    
    try:
        data = await request.json()
        username = data.get('username')
        password = data.get('password')
    except json.JSONDecodeError:
        return json_response({'error': 'Invalid JSON format'}, status=400)
    
    if not (username and password):
        return json_response({'error': 'Missing username or password'}, status=400)

    # 1. 查找用戶
    user_data = await db_manager.fetchone(
        "SELECT password FROM User WHERE username = ?", (username,)
    )

    if not user_data:
        # 為了安全，不區分用戶名不存在還是密碼錯誤
        return json_response({'error': 'Invalid credentials'}, status=401)
        
    # 2. 驗證密碼
    hashed_password = user_data['password']
    if not pbkdf2_sha256.verify(password, hashed_password):
        return json_response({'error': 'Invalid credentials'}, status=401)

    # 3. 生成新的會話鍵
    session_key = str(uuid.uuid4())
    current_time = int(time.time())

    # 4. 更新/插入 Session Table
    # 確保每個用戶只有一個活躍會話，先刪除舊的
    await db_manager.execute(
        "DELETE FROM Session WHERE username = ?", (username,)
    )
    
    await db_manager.execute(
        "INSERT INTO Session (session_key, active_time, username) VALUES (?, ?, ?)",
        (session_key, current_time, username)
    )

    return json_response({'message': 'Login successful', 'session_key': session_key})

async def api_logout(request):
    """
    功能 4. POST API - /__api__/logout/ : 移除 Session Table 中的會話條目。
    """
    db_manager = request.app['db_manager']
    
    try:
        data = await request.json()
        session_key = data.get('session_key')
    except json.JSONDecodeError:
        return json_response({'error': 'Invalid JSON format'}, status=400)

    if not session_key:
        return json_response({'error': 'Missing session_key'}, status=400)

    # 1. 刪除 Session Table 中的條目
    result = await db_manager.execute(
        "DELETE FROM Session WHERE session_key = ?", (session_key,)
    )

    # aiosqlite 的 execute 返回值沒有 rowcount，這裡我們假設刪除成功
    # 實際應用中，可以先 SELECT 判斷是否存在
    
    return json_response({'message': 'Logout successful'})
    
async def api_save_i(request):
    """
    功能 5. POST API - /__api__/save_i/ : 驗證會話鍵，在 Mission Table 中創建條目。
    """
    db_manager = request.app['db_manager']
    
    try:
        data = await request.json()
        session_key = data.get('session_key')
        target_path = data.get('target_path')
    except json.JSONDecodeError:
        return json_response({'error': 'Invalid JSON format'}, status=400)

    if not (session_key and target_path):
        return json_response({'error': 'Missing session_key or target_path'}, status=400)

    # 1. 驗證會話
    username = await db_manager.verify_session(session_key)
    if not username:
        return json_response({'error': 'Invalid or expired session_key'}, status=401)

    # 2. 安全檢查: 確保 target_path 是相對路徑且不允許 '..' 跳出 store 目錄
    if '..' in target_path or target_path.startswith('/'):
        return json_response({'error': 'Target path security violation'}, status=403)
        
    current_time = int(time.time())

    # 3. 創建 Mission Table 條目
    await db_manager.execute(
        "INSERT INTO Mission (target, create_time, session_key) VALUES (?, ?, ?)",
        (target_path, current_time, session_key)
    )

    return json_response({'message': 'Mission initialized', 'target_path': target_path})

async def api_save(request):
    """
    功能 6. POST API - /__api__/save/ : 查找 target path，並將請求體保存到 {ROOT}/store/target_path。
    需要提供 session_key 和 target_path。
    """
    db_manager = request.app['db_manager']

    try:
        # 注意: 這裡我們預期 JSON 包含 session_key 和 target_path，
        # 但 'save' 操作的 body 是要保存的數據，所以我們需要區分
        # 我們假設 session_key 和 target_path 在查詢參數或標頭中，
        # 但為了簡單和貼合 JSON 請求體，我們從 JSON 獲取控制信息，並將其餘的視為數據。
        # 為了符合常規設計，我們假設用戶發送一個 JSON 包含控制信息，**然後**再發送數據。
        # 但這裡我們將 `data` 視為要保存的內容，控制信息來自查詢參數或另一個字段。
        
        # 為了簡單起見，我們假設請求是 multipart/form-data 或其他方式，
        # 但如果請求是 application/json，我們會將整個 body 視為要保存的內容。
        
        # **修正:** 為了與 save_i 流程一致，我們從 JSON 獲取 session_key 和 target_path，
        # 並且假設要保存的內容在另一個名為 'content' 的字段中。
        data = await request.json()
        session_key = data.get('session_key')
        target_path = data.get('target_path')
        content = data.get('content') # 假設這是要保存的數據

    except json.JSONDecodeError:
        # 如果不是 JSON 請求，我們可以讀取整個 body
        # 這是更靈活的設計，但我們暫時堅持 JSON 格式
        return json_response({'error': 'Invalid JSON format'}, status=400)

    if not (session_key and target_path and content is not None):
        return json_response({'error': 'Missing session_key, target_path, or content'}, status=400)

    # 1. 驗證會話和 Mission
    username = await db_manager.verify_session(session_key)
    if not username:
        return json_response({'error': 'Invalid or expired session_key'}, status=401)
        
    mission = await db_manager.fetchone(
        "SELECT target FROM Mission WHERE session_key = ? AND target = ?",
        (session_key, target_path)
    )

    if not mission:
        return json_response({'error': 'Mission not found or unauthorized'}, status=403)

    # 2. 構建安全的文件完整路徑
    full_path = os.path.join(db_manager.store_dir, target_path)
    
    # 確保父目錄存在
    os.makedirs(os.path.dirname(full_path), exist_ok=True)

    # 3. 儲存內容
    try:
        # 這裡我們將 content 視為字串並寫入
        with open(full_path, 'w', encoding='utf-8') as f:
            f.write(str(content))
        
        # 可選: 寫入成功後刪除 Mission Table 中的條目
        # await db_manager.execute("DELETE FROM Mission WHERE session_key = ? AND target = ?", (session_key, target_path))
        
        return json_response({'message': 'File saved successfully', 'path': target_path})
    except Exception as e:
        print(f"File save error: {e}")
        return json_response({'error': f'Failed to save file: {e}'}, status=500)


async def api_load(request):
    """
    功能 7. POST API - /__api__/load/ : 驗證會話鍵，響應 {ROOT}/store/target_path 的文件內容。
    """
    db_manager = request.app['db_manager']
    
    try:
        data = await request.json()
        session_key = data.get('session_key')
        target_path = data.get('target_path')
    except json.JSONDecodeError:
        return json_response({'error': 'Invalid JSON format'}, status=400)

    if not (session_key and target_path):
        return json_response({'error': 'Missing session_key or target_path'}, status=400)

    # 1. 驗證會話
    username = await db_manager.verify_session(session_key)
    if not username:
        return json_response({'error': 'Invalid or expired session_key'}, status=401)
        
    # 2. 構建安全的文件完整路徑
    full_path = os.path.join(db_manager.store_dir, target_path)
    
    # 3. 讀取並響應文件
    if not os.path.exists(full_path) or not os.path.isfile(full_path):
        return json_response({'error': 'File not found'}, status=404)
        
    # 確保文件在 store_dir 內 (安全檢查)
    if not os.path.abspath(full_path).startswith(os.path.abspath(db_manager.store_dir)):
        return json_response({'error': 'Security path violation'}, status=403)

    try:
        with open(full_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # 響應文件內容
        return json_response({'message': 'File loaded successfully', 'target_path': target_path, 'content': content})
    except Exception as e:
        return json_response({'error': f'Failed to read file: {e}'}, status=500)

# --- 4. 應用程式設置和啟動 ---

async def init_app(args):
    """應用程式的異步初始化。"""
    
    db_manager = DBManager(args.root)
    # 啟動時初始化資料庫
    await db_manager.init_db()

    # **可選: 創建一個初始測試用戶**
    # 實際應用中應該有註冊介面，但這裡為了測試方便手動創建一個。
    # 密碼是 'password123'
    test_username = 'testuser'
    test_password_hash = pbkdf2_sha256.hash('password123')
    try:
        await db_manager.execute(
            "INSERT INTO User (username, phone, email, password) VALUES (?, ?, ?, ?)",
            (test_username, '1234567890', 'test@example.com', test_password_hash)
        )
        print(f"已創建測試用戶: {test_username} / password123")
    except aiosqlite.IntegrityError:
        # 如果用戶已存在，則跳過
        print(f"測試用戶 {test_username} 已存在，跳過創建。")

    app = web.Application()
    # 將 DBManager 實例附加到應用程式，以便在視圖中訪問
    app['db_manager'] = db_manager
    app['root_dir'] = args.root
    
    # --- 路由設置 ---
    
    # 2. HTTP GET: 響應 {ROOT}/docs/ 下的文件
    docs_path = os.path.join(args.root, 'docs')
    if not os.path.exists(docs_path):
        os.makedirs(docs_path)
        print(f"創建 docs 目錄: {docs_path}")
        # 創建一個簡單的 index.html 方便測試
        with open(os.path.join(docs_path, 'index.html'), 'w', encoding='utf-8') as f:
            f.write("<h1>Welcome to the Docs!</h1><p>Static files are served from here.</p>")

    # 設置靜態文件服務: 處理 / 的 GET 請求
    app.router.add_static('/', docs_path, name='static_docs', show_dirs=True)

    # API 路由
    app.router.add_post('/__api__/login/', api_login, name='api_login')
    app.router.add_post('/__api__/logout/', api_logout, name='api_logout')
    app.router.add_post('/__api__/save_i/', api_save_i, name='api_save_i')
    app.router.add_post('/__api__/save/', api_save, name='api_save')
    app.router.add_post('/__api__/load/', api_load, name='api_load')
    
    return app

def main():
    """主函數，解析參數並運行服務器。"""
    args = parse_args()

    # 1. 確保 root 目錄存在
    if not os.path.isdir(args.root):
        print(f"錯誤: 根目錄 {args.root} 不存在或不是目錄。請先創建。")
        return

    # 啟動 aiohttp 服務
    web.run_app(
        init_app(args),
        host='0.0.0.0', # 監聽所有接口
        port=args.port
    )

if __name__ == '__main__':
    main()
